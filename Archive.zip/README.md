# UnlockFit

## Project Overview
UnlockFit is a comprehensive, gamified wellness app that tightly weaves together physical activity and digital wellness goals through HealthKit and Firebase Firestore’s real time sync. At its core, UnlockFit requires you to meet personalised fitness challenges, steps, active calories and flights climbed, to “earn” screen time sessions you can then start and stop yourself, promoting discipline and rewarding healthy behaviour. Behind the scenes, every HealthKit reading and goal adjustment immediately writes to Firestore (and propagates across your devices via snapshot listeners), while milestone progress, visualised as concentric rings and dot arrays, and seven day screen time logs persist in arrays that unlock extra sessions as you hit thresholds. The result is a seamless loop: move to earn digital freedom, track both metrics in real time, and see weekly trends and your “best day” highlighted in the Progress tab. Offline caching makes sure there's no data loss, midnight resets guarantee a fresh start each day, and customisable profile and notification settings, all bound to Firestore, let you tailor the experience so UnlockFit not only motivates physical well being but also cultivates mindful screen time balance in one unified, interactive package.

---

## Key Features
- **Authentication & Registration:** Secure login and registration flows with inline validation, initial Firestore user document creation, and illustrated notification setup.
- **Real-Time Fitness Challenges:** Complete step, calorie, and flight goals to earn app sessions; progress rings driven by HealthKit and synchronized via Firestore.
- **Custom Goal-Setting:** Create personalised fitness challenges with adjustable targets.
- **Dynamic Themes:** Multiple UI themes—Default, Neon, Ulku, Performance, Slate, Aurora, Cyberpunk—for a tailored look.
- **Screen Time Management:** Track and limit app usage with Firestore-backed session arrays and lock overlays when limits are reached.
- **Dynamic Island Live Activity:** Live countdown ring for active sessions displayed in the Dynamic Island and on the Lock Screen.
- **Data Visualization:** Weekly trend graphs, best-day highlights, and detailed insights based on historical HealthKit and screen time data.
- **Offline Persistence:** Automatic queueing and synchronization of Firestore updates when connectivity is restored.
- **Daily Reset Routine:** Scheduled reset of daily aggregates, milestones, and screen time arrays at midnight.

---

## Technology Stack
- **Swift and SwiftUI:** For seamless UI development and declarative design.
- **HealthKit API:** Integrated to track fitness metrics like steps, active energy, and flights climbed.
- **Firebase Firestore:** Real-time synchronization, offline caching, and snapshot listeners for user data.
- **GitLab:** Used for version control and collaborative development.
- **Screen Time API:** Depreciated / Not used due to limitations; screen time logic is custom-implemented using Firestore and internal session tracking.

---

## Repository Structure
```
/
|-- product/           # Core project files for UnlockFit.
|-- documents/         # Reports, presentations, and related files.
|-- diary.md           # Project diary tracking progress and updates.
|-- README.md          # Overview of the project.
|-- .gitignore         # Excludes unnecessary files from version control.
```

---

## Firestore Architecture
- **users (collection)**: Each document is keyed by the user’s UID and stores:
  - `nickname`, `email`, `theme`, and `profileImageURL`
  - `stepGoal`, `calorieGoal`, `flightsGoal`
  - `stepGoalArray`, `calorieGoalArray`, `flightsGoalArray` (milestone tracking: 0 = unmet, 1 = unlocked, 2 = used)
  - `screenTimeSeconds`, `screenTimeSessions` (arrays indexed for 7-day tracking)
- **Realtime Listeners:** Sync user data, theme, fitness progress, and screen time sessions live across devices.
- **Offline Persistence:** Enables queued writes and automatic sync when connection is restored.

---

## Current Progress
- **Authentication & Registration:** Implemented login, registration forms, Firestore user initialization, and notification setup.
- **Core UI & Navigation:** Built main tabs (Fitness, Screen Time, Progress, Profile) with SwiftUI.
- **Firestore Integration:** Snapshot listeners and writes for real-time updates of goals, milestones, and sessions.
- **Fitness Tab:** Three concentric progress rings linked to HealthKit and Firestore, milestone tracking with animated dots.
- **Screen Time Tab:** Seven-day bar chart, session management, lock overlays, and Firestore-backed arrays.
- **Progress Tab:** Multi-line weekly trends, best-day computation, and real-time UI updates.
- **Profile Tab:** Settings bound to Firestore fields, theme selection, privacy info, and logout.
- **Custom Features:** Custom goal-setting and enhanced data visualization.
- **Offline Support & Daily Reset:** Offline persistence and scheduled midnight resets.

---

## Upcoming Milestones
- **Integrate Screen Time API:** Contact Apple for access to the Screen Time API and explore incorporation into future app updates once available.
- **Community Features:** Explore options for shared challenges and leaderboards.

---

## How to Run
1. Clone this repository:
   ```bash
   git clone https://gitlab.cim.rhul.ac.uk/zlac300/PROJECT.git
   ```
2. Open the project in Xcode.
3. Select your target device or simulator.
4. Build and run the project.
5. Ensure HealthKit permissions are enabled in your device’s Settings for full functionality.

---

## Screenshots / Demo Link
*Coming soon.*

---

## Contributing
After the 24th of April 2025, contributions are welcome! If you'd like to contribute to UnlockFit, please fork the repository and create a pull request with your proposed changes.

---

## Contact
**Developer:** Nick Kohli  
**Supervisor:** Dr. Nguyen Khuong  
For any questions or feedback, please contact zlac300@live.rhul.ac.uk.
