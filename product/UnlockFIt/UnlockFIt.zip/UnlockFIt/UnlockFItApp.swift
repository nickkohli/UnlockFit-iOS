//
//  UnlockFItApp.swift
//  UnlockFIt
//
//  Created by woozy on 05/12/2024.
//

import SwiftUI
import UIKit

@main
struct UnlockFitApp: App {
    @StateObject private var themeManager = ThemeManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(themeManager) // Pass ThemeManager to the app
                .onAppear {
                    themeManager.applyTheme() // Ensure theme is applied initially
                }
        }
    }
}
